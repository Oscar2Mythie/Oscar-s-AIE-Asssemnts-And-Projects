@echo off

set "EXT=.exe"

for %%f in (*%EXT%) do (
	set "PROJECT_EXE=%%f"
    set "PROJECT_NAME=%%~nf"
	goto :file_read
)

:file_read

echo "Running project %PROJECT_NAME%"
set WEBSERVER_FOLDER=%PROJECT_NAME%\Samples\PixelStreaming\WebServers
set ORIGINAL_DIR=%CD%

pushd .
call 1-GetServer.bat "%WEBSERVER_FOLDER%"
popd

pushd .
start "" 2-RunGame.bat "%PROJECT_NAME%"
popd

pushd .
call 3-RunServer.bat "%WEBSERVER_FOLDER%"
popd