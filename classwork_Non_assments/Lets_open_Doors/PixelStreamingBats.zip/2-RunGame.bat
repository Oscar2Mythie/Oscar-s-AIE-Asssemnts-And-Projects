pause

:: Open up the webpage automagically
start "" http://127.0.0.1

:: Start the game
"%1.exe" -RenderOffScreen -AudioMixer -PixelStreamingIP=localhost -PixelStreamingPort=8888