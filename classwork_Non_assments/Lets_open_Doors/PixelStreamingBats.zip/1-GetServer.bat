SET WEBSERVER_FOLDER=%1

IF NOT EXIST "%WEBSERVER_FOLDER%\SignallingWebServer\" (
	echo "Webserver does not exist... retrieving..."
	call "%WEBSERVER_FOLDER%\get_ps_servers.bat"
)