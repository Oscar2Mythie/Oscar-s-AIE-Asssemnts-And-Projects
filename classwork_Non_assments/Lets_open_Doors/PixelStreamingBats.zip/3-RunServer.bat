SET WEBSERVER_FOLDER=%1

%WEBSERVER_FOLDER%\SignallingWebServer\platform_scripts\cmd\run_local.bat
